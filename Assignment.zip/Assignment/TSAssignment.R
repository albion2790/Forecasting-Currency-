library(lubridate)
library(ggplot2)
library(trend)
library(forecast)
library(seasonal)
library(tseries)
library(sarima)
library(lmtest)


#Transforming to a Date object#
str(exchange_rates)
exchange_rates$new_date <- dmy(exchange_rates$DATE)
head(exchange_rates)
str(exchange_rates)
View(exchange_rates)

#creating a default plot and time series plot
defaultPlot <- ggplot(exchange_rates, aes(x=new_date, y=USD)) +
  geom_line()

defaultPlot

tsp <- ts(exchange_rates$USD, frequency = 7, start = c(2022, 1))

tsp

plot.ts(tsp)

#Testing the trend by using Mann-Kendall trend test
mk.test(tsp)



#Part C
#Splitting the dataset 80% training 20% test 

split<-0.8
training_set<-ts(tsp[1:(length(tsp)*split)], frequency = 7)
test_set<-ts(tsp[-c(1:(length(tsp)*split))], frequency = 7)
head(training_set)
length(training_set)
length(test_set)


#Simple Exponential Smoothing 
SES_M = HoltWinters(training_set, beta = FALSE, gamma = FALSE)
SES_F = forecast::forecast(SES_M, h = length(test))
plot(SES_F,xlab = "Date", ylab = "Ringgit to USD exchange rates in 2022", lwd = 2)
lines(fitted(SES_M)[,1], col="red", lwd=2)
legend("topleft", legend = c("Historical data", "Train data", "Test data"), col=c("black", "red", "blue"), lty = 1)

#Linear Regression Model with Dummy variables

plot (tsp)
time = 1:length(training_set)
season = seasonaldummy(tsp)
lmM=tslm(training_set ~ time + season )
k = length(training_set)
lmF = forecast::forecast(lmM, data.frame(time = k+1:length(tsp)))

plot(lmF,ylab= "Daily exchange rate of Ringgit in USD 2022", lwd=2)
lines(fitted(lmM), col='red', lwd=2)
legend("bottomright", legend = c("Historical data", "Train data", "Test data"), col=c("black", "red", "blue"), lty = 1)



#Holt-winter method

modelHw = HoltWinters(training_set, seasonal = "additive")
modelHw_F = forecast::forecast(modelHw,h= length(test_set))
summary(modelHw_F)

plot(modelHw_F,xlab = "Date", ylab = "Ringgit to USD exchange rates in 2022", lwd = 2)
lines(fitted(modelHw)[,1],col="red", lwd=2)
legend("topleft", legend = c("Historical data", "Train data", "Test data"), col=c("black", "red", "blue"), lty = 1)

#Part D
#Forecast error measures
#Holt Winter
modelHw_F
modelHw_F$mean
modelHw_F_mean=modelHw_F$mean
modelHw_F_mean=ts(modelHw_F_mean, frequency = 7)
accuracy(modelHw_F_mean, test_set)

#Linear Regression Model with Dummy variablelmF
lmF$mean
lmF_mean =lmF$mean
lmF_mean = ts(lmF_mean,frequency = 7)
rbind(accuracy(lmM), accuracy(lmF_mean, test_set))

#simple exponential smoothing
SES_F
SES_F$mean
SES_F_mean = SES_F$mean
SES_F_mean = ts(SES_F_mean, frequency = 7)
accuracy(SES_F_mean, test_set)

#Part E


#ACF plot of time series
acf(tsp, lag.max = 28 ) #dying down
pacf(tsp, lag.max = 28 )
adf.test(tsp)
tseries::kpss.test(tsp)
ndiffs(tsp)

#stabilization of the time series
BoxCox.lambda(tsp)
tsd = sqrt(tsp)
tseries::kpss.test(diff(tsd,7))
ndiffs(diff(tsd,7))

#part F
#(i)
#ACF and PACF Plot
acf(diff(tsd, 7), lag.max = 28)
pacf(diff(tsd, 7), lag.max = 28)
auto.arima(tsp)
sarima::autofit = auto.arima(tsp, trace = TRUE, stationary = FALSE, seasonal = TRUE)

#(ii)
#model summary for our 2 summary model 
sarima1 = arima(training_set, order = c(2, 0, 0), seasonal = c(0,1,1))
summary(sarima1)

sarima2 = arima(training_set, order = c(2, 0, 1), seasonal = c(0,1,1))
summary(sarima2)

#(iv)
#Adequacy of the model
checkresiduals(sarima1)
checkresiduals(sarima2)

#v
#Testing the significance of each coeffiecients
coeftest(sarima1)
coeftest(sarima2)

#vi
summary(sarima2)

#g
#Forecasting of the next 20 years using sarima2
plot(forecast(sarima2,h=20))










